﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FMODUnity;
using FMOD;

public class UiSound : MonoBehaviour
{
    private static UiSound instance;
    public static UiSound GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<UiSound>();
            
            if (instance == null)
            {
                GameObject container = new GameObject("Sound_Manger");

                instance = container.AddComponent<UiSound>();
            }
        }
        return instance;
    }

    [FMODUnity.EventRef] public string background_Bgm_Game; // 0스테이지 BGM
    [FMODUnity.EventRef] public string Select_Sound; // 
    [FMODUnity.EventRef] public string Click_Sound; // 


    FMOD.Studio.EventInstance BGM_Game;

    void Start()
    {
        DontDestroyOnLoad(this.gameObject);
        BGM_Game = FMODUnity.RuntimeManager.CreateInstance(background_Bgm_Game);

        Background_Bgm_Game_Start();
    }

    public void Select_Sound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Select_Sound);
    }
    public void Click_Sound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Click_Sound);
    }

    public void Background_Bgm_Game_Start()
    {
        BGM_Game.start();
    }
    public void BackGround_Bgm_Game_Stop()
    {
        BGM_Game.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }
}