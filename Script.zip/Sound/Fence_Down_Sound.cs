﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FMODUnity;
using FMOD;

public class Fence_Down_Sound : MonoBehaviour
{
    Rigidbody rigid;
    public bool sound = true;
    [FMODUnity.EventRef] public string Fence_Sound; // 0스테이지 BGM


    private void Start()
    {
        rigid = GetComponent<Rigidbody>();
    }

    public void Cabinet_OffSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Fence_Sound);
    }

    private void Update()
    {
        if (rigid.velocity.y <= -1.5f && sound)
        {
            Cabinet_OffSound_Start();
            sound = false;
        }
    }
}
