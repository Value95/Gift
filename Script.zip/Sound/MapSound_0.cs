﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FMODUnity;
using FMOD;
using Debug = UnityEngine.Debug;

public class MapSound_0 : MonoBehaviour
{
    private static MapSound_0 instance;
    public static MapSound_0 GetInstance() // 싱글턴
    {
        if (instance == null)
        {
            instance = FindObjectOfType<MapSound_0>();

            if (instance == null)
            {
                GameObject container = new GameObject("Sound_Manger");

                instance = container.AddComponent<MapSound_0>();
            }
        }
        return instance;
    }

    [FMODUnity.EventRef] public string background_Bgm_Game; // 0스테이지 BGM
    [FMODUnity.EventRef] public string watchtower_bullet_Sound; // 감시탑총알사운드
    [FMODUnity.EventRef] public string extraman_bullet_Sound; // 감시탑총알사운드
    [FMODUnity.EventRef] public string breaker_Up_Sound; // 차단기 올라가는사운드
    [FMODUnity.EventRef] public string Door_On_Sound; // 문열기
    [FMODUnity.EventRef] public string Door_Off_Sound; // 문닫기
    [FMODUnity.EventRef] public string Cabinet_Off_Sound; // 캐비넷나오기
    [FMODUnity.EventRef] public string Cabinet_On_Sound; // 캐비넷들어가기
    [FMODUnity.EventRef] public string Light_On_Sound; // 캐비넷들어가기

    [FMODUnity.EventRef] public string Chase_On_Sound; // 쫒길때 사운드

    [FMODUnity.EventRef] public string TV_On_Sound; // TV소리
    [FMODUnity.EventRef] public string TV_Off_Sound; // TV소리

    [FMODUnity.EventRef] public string Electricity; // TV소리

    [FMODUnity.EventRef] public string eventsound_0; // TV소리
    [FMODUnity.EventRef] public string eventsound_1; // TV소리
    [FMODUnity.EventRef] public string eventsound_2; // TV소리
    [FMODUnity.EventRef] public string eventsound_3; // TV소리
    [FMODUnity.EventRef] public string eventsound_4; 
    [FMODUnity.EventRef] public string eventsound_5;
    FMOD.Studio.EventInstance BGM_Game;
    FMOD.Studio.EventInstance TV_On;
    FMOD.Studio.EventInstance TV_Off;
    FMOD.Studio.EventInstance LightOn;
    FMOD.Studio.EventInstance Chase_On;
    FMOD.Studio.EventInstance Electricity_Sound;

    FMOD.Studio.EventInstance boxPush;
    void Start()
    {
        DontDestroyOnLoad(this.gameObject);
        BGM_Game = FMODUnity.RuntimeManager.CreateInstance(background_Bgm_Game);
        TV_On = FMODUnity.RuntimeManager.CreateInstance(TV_On_Sound);
        TV_Off = FMODUnity.RuntimeManager.CreateInstance(TV_Off_Sound);
        LightOn = FMODUnity.RuntimeManager.CreateInstance(Light_On_Sound);
        Chase_On = FMODUnity.RuntimeManager.CreateInstance(Chase_On_Sound);
        Electricity_Sound = FMODUnity.RuntimeManager.CreateInstance(Electricity);

        boxPush = FMODUnity.RuntimeManager.CreateInstance(eventsound_5);

        FMODUnity.RuntimeManager.PlayOneShot(background_Bgm_Game);

        Background_Bgm_Game_Start();
    }
    public void Watchtower_BulletSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(watchtower_bullet_Sound);
    }
    public void Extraman_BulletSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(extraman_bullet_Sound);
    }
    public void Breaker_UpSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(breaker_Up_Sound);
    }
    public void Door_OnSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Door_On_Sound);
    }
    public void Door_OffSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Door_Off_Sound);
    }
    public void Cabinet_OffSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Cabinet_Off_Sound);
    }
    public void Cabinet_OnSound_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Cabinet_On_Sound);
    }
    public void eventSound_0_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventsound_0);
    }
    public void eventSound_1_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventsound_1);
    }
    public void eventSound_2_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventsound_2);
    }
    public void eventSound_3_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventsound_3);
    }
    public void eventSound_4_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventsound_4);
    }
    public void Background_Bgm_Game_Start()
    {
        BGM_Game.start();
    }
    public void BackGround_Bgm_Game_Stop()
    {
        BGM_Game.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

    public void TV_On_Start()
    {
        TV_On.start();
    }
    public void TV_On_Stop()
    {
        TV_On.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }
    public void TV_Off_Start()
    {
        TV_Off.start();
    }
    public void TV_Off_Stop()
    {
        TV_Off.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

    public void Electricit_Start()
    {
        Electricity_Sound.start();
    }
    public void Electricit_Stop()
    {
        Electricity_Sound.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

    public void LightOn_Start()
    {
        LightOn.start();
    }
    public void LightOn_Stop()
    {
        LightOn.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }
    public void Chase_On_Start()
    {
        Chase_On.start();
    }

    public void ChaseOn_Stop()
    {
        Chase_On.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

    public void Chase_Ch(int num)
    {
        Chase_On.setParameterByName("Hide", 1);
    }
    public void Box_Push_Start()
    {
        boxPush.start();
    }

    public void Box_Push_Stop()
    {
        boxPush.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }

}

