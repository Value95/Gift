﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SuperFlash : MonoBehaviour
{
    
    public float lightFlashValue_MIN, lightFlashValue_MAX, power;
    public Vector2 littleDelayTime;
    public Vector2 bigDelayTime;
    public Vector2 flashCount;
    Light light;
    Material material;
    // Start is called before the first frame update
    void Start()
    {
        light = GetComponent<Light>();
        material = transform.GetChild(0).GetChild(0).gameObject.GetComponent<MeshRenderer>().material;
        StartCoroutine(Flash());
    }


    IEnumerator Flash()
    {
        float lightValue = 1;
        int flashC = 0;
        int flashCoun = (int)Random.Range(flashCount.x, flashCount.y);
        while (true)
        {
            
                if (material.GetFloat("_Emission") <= lightFlashValue_MIN)
                {
                    lightValue = lightFlashValue_MAX;
                    // yield return new WaitForSeconds(delayTime);
                }
                else if (material.GetFloat("_Emission") >= lightFlashValue_MAX)
                {
                    lightValue = lightFlashValue_MIN;
                flashC++;
                    yield return new WaitForSeconds(Random.Range(littleDelayTime.x, littleDelayTime.y));
                }

                if (material.GetFloat("_Emission") < lightValue)
                {
                    material.SetFloat("_Emission", material.GetFloat("_Emission") + power * Time.deltaTime);
                    light.intensity += power * Time.deltaTime;
                }
                else
                {
                    material.SetFloat("_Emission", material.GetFloat("_Emission") - power * Time.deltaTime);
                    light.intensity -= power * Time.deltaTime;
                }
                yield return new WaitForSeconds(0.01f);
            if (flashC > flashCoun)
            {
                flashCoun = (int)Random.Range(flashCount.x, flashCount.y);
                flashC = 0;
                yield return new WaitForSeconds(Random.Range(bigDelayTime.x, bigDelayTime.y));
            }

        }
    }
}