﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutLineShaderFlash : MonoBehaviour
{
    public Vector2  max, delayTime, changeTime;
    MeshRenderer render;
    public int division;
  void Start()
    {
        render = GetComponent<MeshRenderer>();
        StartCoroutine("Flash");
    }
    IEnumerator Flash()
    {
        while (true)
        {
            for(int i = 0; i < division; i++)
            {
                render.material.SetFloat("_OutlineWidth", max.x * i/ division);
                render.material.SetFloat("_OutlineBright", max.y * i / division);
                yield return new WaitForSeconds(changeTime.x / division);
                
            }
            for (int i = 0; i < division; i++)
            {
                yield return new WaitForSeconds(delayTime.x / division);
            }

            for (int i = 0; i < division; i++)
            {
                render.material.SetFloat("_OutlineWidth", max.x * (division -1- i) / division);
                render.material.SetFloat("_OutlineBright", max.y * (division -1- i) / division);
                yield return new WaitForSeconds(changeTime.y / division);
                
            }
            for (int i = 0; i < division; i++)
            {

                yield return new WaitForSeconds(delayTime.y / division);
            }
        }
    }
}
