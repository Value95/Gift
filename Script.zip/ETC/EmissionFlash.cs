﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmissionFlash : MonoBehaviour
{
    public float lightFlashValue_MIN, lightFlashValue_MAX, delayTime, power;
    MeshRenderer light;

    // Start is called before the first frame update
    void Start()
    {
        light = GetComponent<MeshRenderer>();
        StartCoroutine("LightActive");
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator LightActive()
    {
        float lightValue = 1;
        while (true)
        {
            if (light.material.GetFloat("_Emission") <= lightFlashValue_MIN)
            {
                lightValue = lightFlashValue_MAX;
                // yield return new WaitForSeconds(delayTime);
            }
            else if (light.material.GetFloat("_Emission") >= lightFlashValue_MAX)
            {
                lightValue = lightFlashValue_MIN;
                yield return new WaitForSeconds(delayTime);
            }

            if (light.material.GetFloat("_Emission") < lightValue)
            {
                light.material.SetFloat("_Emission", light.material.GetFloat("_Emission") + power * Time.deltaTime);
            }
            else
            {
                light.material.SetFloat("_Emission", light.material.GetFloat("_Emission") - power * Time.deltaTime);
            }

            yield return new WaitForSeconds(0.01f);
        }

    }
}
