﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightFlashLite : MonoBehaviour
{
    public float lightFlashValue_MIN, lightFlashValue_MAX,delayTime, power;
    Light light;

    // Start is called before the first frame update
    void Start()
    {
        light = GetComponent<Light>();
        StartCoroutine("LightActive");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator LightActive()
    {
        float lightValue = 1;
        while (true)
        {
            if (light.intensity <= lightFlashValue_MIN)
            {
                lightValue = lightFlashValue_MAX;
               // yield return new WaitForSeconds(delayTime);
            }
            else if(light.intensity >= lightFlashValue_MAX)
            {
                lightValue = lightFlashValue_MIN;
                yield return new WaitForSeconds(delayTime);
            }

            if(light.intensity < lightValue )
            {
                light.intensity += power * Time.deltaTime;
            }
            else
            {
                light.intensity -= power * Time.deltaTime;
            }

            yield return new WaitForSeconds(0.01f);
        }

    }
}
