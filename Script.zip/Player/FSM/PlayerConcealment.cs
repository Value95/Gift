﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerConcealment : FSMState
{

    public override void BeginState()
    {
        _manager.anim.SetBool("Concealment", false);
        _manager.playerState = Player_State.Concealment;
        this.GetComponent<PlayerMove>().enabled = false;
        ConcealmentStart();
    }

    // Update is called once per frame
    void Update()
    {

    }

    //오브젝트의 이름을판단
    // 오브젝트의맞는 이벤트실행
    void ConcealmentStart()
    {
        Debug.Log(_manager.interactionObj.GetComponent<ConcealmentEventName>().name);
        switch(_manager.interactionObj.GetComponent<ConcealmentEventName>().name)
        {
            case ConcealmentName.Cabinet:
                _manager.interactionObj.GetComponent<ConcealmentEventName>().EventOn();
                break;
        }
    }
}
