﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPush : FSMState
{
    public Transform map;

    Vector3 target;

    bool targeton = false;
    bool moveon = true;

    public override void BeginState()
    {
        _manager.playerState = Player_State.Push;
        GetComponent<PlayerMove>().enabled = false;

        targeton = false;
        moveon = true;
        target = BoxTarget();
        target.y = this.transform.position.y;
    }

    public override void EndState()
    {
        targeton = false;
        moveon = true;
        _manager.interactionObj.transform.parent = map;
        _manager.anim.SetBool("Push", false);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.UpArrow))
        {
            _manager.interactionObj.layer = 2;
        }

        if (Input.GetKeyUp(KeyCode.DownArrow) || Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.UpArrow))
        {
            _manager.interactionObj.layer = 0;

        }

        if (target != this.transform.position && moveon)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, 10 * Time.deltaTime);
            return;
        }
        else if (target == this.transform.position && moveon)
        {
            moveon = false;
            targeton = true;
        }

        if (targeton)
        {
            this.transform.GetChild(0).transform.LookAt(_manager.interactionObj.transform);  // .rotation = Quaternion.Euler(0, 90, 0); // 박스를바라보게
            _manager.interactionObj.transform.parent = this.transform;
            _manager.anim.SetBool("Push", true);
            targeton = false;
            GetComponent<PlayerMove>().enabled = true;
        }

        if(Input.GetKey(KeyCode.LeftControl))
        {
            GetComponent<PlayerMove>().enabled = false;
            _manager.anim.SetBool("PushConcealment", true);
        }
        else if(Input.GetKeyUp(KeyCode.LeftControl))
        {
            GetComponent<PlayerMove>().enabled = true;
            _manager.anim.SetBool("PushConcealment", false);
        }

        if (Input.GetKeyDown(KeyCode.Z))
        {
            PushEnd();
        }
    }

    public void PushEnd()
    {
        _manager.ChScript(Player_State.Idle);
        _manager.interactionObj.layer = 0;
    }

    // 가장가까운타겟을찾는다.
    Vector3 BoxTarget()
    {
        float dir = float.MaxValue;
        Vector3 returnPos = Vector3.zero;
        for(int i=0; i < 4; i++)
        {
            float Tdir = Vector3.Distance(_manager.interactionObj.transform.GetChild(i).gameObject.transform.position, this.transform.position);

            if(dir > Tdir)
            {
                dir = Tdir;
                returnPos = _manager.interactionObj.transform.GetChild(i).gameObject.transform.position;
                _manager.targetname = _manager.interactionObj.transform.GetChild(i).gameObject;
            }
        }
        
        return returnPos;
    }
}
