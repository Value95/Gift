﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPickup : FSMState
{
    public override void BeginState()
    {
        _manager.playerState = Player_State.Pickup;
    }
    
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }

}
