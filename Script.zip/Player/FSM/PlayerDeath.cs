﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDeath : FSMState
{

    public override void BeginState()
    {
        this.GetComponent<PlayerMove>().enabled = false;
        _manager.interactionObj = null;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
