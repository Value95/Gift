﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIdle : FSMState
{

    public override void BeginState()
    {
        _manager.playerState = Player_State.Idle;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if (_manager.interactionObj != null)
            {
                switch (_manager.interactionObj.tag)
                {
                    case "BoxObject":
                        _manager.ChScript(Player_State.Push);
                        break;
                    case "Button":
                        EventOn();
                        break;
                    case "Concealment":
                        _manager.ChScript(Player_State.Concealment);
                        break;
                    case "EventObj":
                        EventOn();
                        break;
                }
            }
        }
    }

    private void OnTriggerStay(Collider col)
    {
        switch (col.tag)
        {
            case "BoxObject":
                _manager.interactionObj = col.gameObject;
                break;
            case "Button":
                _manager.interactionObj = col.gameObject;
                break;
            case "Concealment":
                _manager.interactionObj = col.gameObject;
                break;
            case "EventObj":
                _manager.interactionObj = col.gameObject;
                break;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if(_manager.interactionObj && _manager._CurrentState == Player_State.Idle)
        {
            _manager.interactionObj = null;
        }
    }

    void EventOn()
    {
        _manager.interactionObj.GetComponent<ObjectEventName>().EventOn();
    }
}