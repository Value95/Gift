﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimEvent : MonoBehaviour
{
    public PlayerMove move;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void PlayerMoveStart()
    {
        transform.parent.GetComponent<PlayerMove>().enabled = true;
    }

    void PanceOff()
    {
        this.transform.parent.transform.position = this.transform.GetChild(0).transform.position;
        this.transform.localPosition = Vector3.zero;
        transform.parent.GetComponent<PlayerFSM>().anim.SetBool("Fance_Slading", false);
        transform.parent.GetComponent<PlayerMove>().enabled = true;
    }

    // 하위의 오브젝트위치에 상위오브젝트위치를맞춤
    public void Positioning()
    {
        this.transform.parent.transform.position = this.transform.transform.position;
        this.transform.localPosition = Vector3.zero;
        this.transform.parent.GetComponent<PlayerMove>().enabled = true;
    }

    void MoveOn()
    {
        move.enabled = true;
    }

    void MoveOff()
    {
        move.enabled =false;
    }
}