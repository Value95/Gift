﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Player_State
{
    Idle,
    Pickup,
    Concealment,
    Push,
    Death
}

[RequireComponent(typeof(Player_State))]
public class PlayerFSM : MonoBehaviour {

    [HideInInspector] public bool cutter = false;
    [HideInInspector] public bool key = false;

    public GameObject interactionObj;
    [HideInInspector] public GameObject targetname;

    private bool _isinit = false;
    Player_State startState = Player_State.Idle;

    private Dictionary<Player_State, FSMState> _states = new Dictionary<Player_State, FSMState>();

    private Player_State currentState;
    public Player_State _CurrentState { get { return currentState; }  }

    public Player_State playerState;

    [HideInInspector] public Animator anim;
    
    // Use this for initialization
    void Awake () {
        anim = transform.GetChild(0).GetComponent<Animator>();
        playerState = startState;

        Player_State[] stateValues = (Player_State[])System.Enum.GetValues(typeof(Player_State));
        foreach (Player_State s in stateValues)
        {
            System.Type FSMType = System.Type.GetType("Player"+s.ToString());
            FSMState state = (FSMState)GetComponent(FSMType);
            if (null == state)
            {
                state = (FSMState)gameObject.AddComponent(FSMType);
            }
            _states.Add(s, state);
            state.enabled = false;
        }

    }

    void Start()
    {
        ChScript(startState);
        _isinit = true;
    }

    public void ChScript(Player_State newState)
    {
        if (_isinit)
        {
            _states[currentState].enabled = false;
            _states[currentState].EndState();
        }
        currentState = newState;
        _states[currentState].BeginState();
        _states[currentState].enabled = true;
    }


}