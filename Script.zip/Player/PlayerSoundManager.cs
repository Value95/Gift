﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using FMODUnity;
using FMOD;

public class PlayerSoundManager : MonoBehaviour
{

    [FMODUnity.EventRef] public string noraml_Wark; // 일반걷기
    [FMODUnity.EventRef] public string noraml_Run; // 일반뛰기
    [FMODUnity.EventRef] public string Water_noraml_Wark; // 일반걷기
    [FMODUnity.EventRef] public string Water_noraml_Run; // 일반뛰기
    [FMODUnity.EventRef] public string button_Push; // 버튼누르기
    [FMODUnity.EventRef] public string box_Climb_Up; // 박스올라가기
    [FMODUnity.EventRef] public string box_Climb_Down; // 박스올라가기
    [FMODUnity.EventRef] public string Tbox_Push; // 박스밀기

    [FMODUnity.EventRef] public string Item_Push; 

    FMOD.Studio.EventInstance noramlWark;
    FMOD.Studio.EventInstance noramlRun;
    FMOD.Studio.EventInstance boxPush;

    public bool Water = false;

    void Start()
    {
        boxPush = FMODUnity.RuntimeManager.CreateInstance(Tbox_Push);
    }

    public void Normal_Wark_Sound()
    {
        if (Water)
        {
            FMODUnity.RuntimeManager.PlayOneShot(Water_noraml_Wark);
        }
        else
        {
            FMODUnity.RuntimeManager.PlayOneShot(noraml_Wark);
        }

    }
    public void Normal_Run_Sound()
    {
        if (Water)
        {
            FMODUnity.RuntimeManager.PlayOneShot(Water_noraml_Run);
        }
        else
        {
            FMODUnity.RuntimeManager.PlayOneShot(noraml_Run);
        }

    }
    public void Button_Push_Sound()
    {
        FMODUnity.RuntimeManager.PlayOneShot(button_Push);
    }
    public void box_Climb_Up_Sound()
    {
        FMODUnity.RuntimeManager.PlayOneShot(box_Climb_Up);
    }
    public void box_Climb_Down_Sound()
    {
        FMODUnity.RuntimeManager.PlayOneShot(box_Climb_Down);
    }
    public void Box_Push_Start()
    {
       FMODUnity.RuntimeManager.PlayOneShot(Tbox_Push);
       //boxPush.start();
    }

    public void Box_Push_Stop()
    {
        boxPush.stop(FMOD.Studio.STOP_MODE.ALLOWFADEOUT);
    }
    public void Item_Push_Start()
    {
        FMODUnity.RuntimeManager.PlayOneShot(Item_Push);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Water")
        {
            Water = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Water")
        {
            Water = false;
        }
    }
}
