﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum MoveType
{
    Idle = 0,
    Walk,
    WalkDown
}

public class PlayerMove : MonoBehaviour
{
    [SerializeField]
    float gravity;      //중력

    PlayerFSM fsm;

    float player_Speed;
    public float _Speed { get { return player_Speed; } set { player_Speed = value; } }

    CharacterController cc;
    public Vector3 move = Vector3.zero;

    PlayerState state;

    Transform myTransform;
    Transform model;

    [HideInInspector] public Animator anim;

    float forward = 0;
    float forward_Max = 0.5f;

    float animSpeed = 7;

    // Start is called before the first frame update
    void Start()
    {
        cc = this.transform.GetComponent<CharacterController>();
        fsm = transform.GetComponent<PlayerFSM>();
        state = transform.GetComponent<PlayerState>();
        model = transform.GetChild(0);
        myTransform = this.transform;
        anim = transform.GetChild(0).GetComponent<Animator>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.LeftShift) && !Input.GetKey(KeyCode.LeftControl)) // 달리기
        {
            Run();
        }
        else
        {
            forward_Max = 0.5f;
            player_Speed = state.warkSpeed;
        }

        if (Input.GetKey(KeyCode.LeftControl)) // 앉기
        {
            anim.SetFloat("Sit", Mathf.Min(anim.GetFloat("Sit") + Time.deltaTime * 4, 1));
            cc.height = 1.18f;
            cc.center = new Vector3(0, 0.6f, 0);
        }
        else
        {
            anim.SetFloat("Sit", Mathf.Max(anim.GetFloat("Sit") - Time.deltaTime * 4, 0));
            cc.height = 1.51f;
            cc.center = new Vector3(0, 0.77f, 0);
        }

        if (cc.isGrounded)
        {
            if (fsm._CurrentState != Player_State.Push) // 이동
                Movecle();
            else
            {
                switch(fsm.targetname.name)
                {
                    case "Target_F":
                        pushMove_F();
                        break;
                    case "Target_B":
                        pushMove_B();
                        break;
                    case "Target_L":
                        pushMove_L();
                        break;
                    case "Target_R":
                        pushMove_R();
                        break;
                }
                
            }
            anim.SetBool("PlayerDown", false);
        }
        else
        { // 공중상태에서 내려가기
            move.y -= gravity * Time.deltaTime;
            if (move.y <= -1.0f) // 공중내려가는속도가 -1이 될때 내려가는애니출력
            {
                if (Physics.Raycast(this.transform.position, Vector3.down, 1.0f))
                    anim.SetBool("PlayerDown", false);
                else
                    anim.SetBool("PlayerDown", true);
            }
        }


        if (Input.GetKeyDown(KeyCode.Space)) // 오브젝트올라가기
        {
            ObjectGoUp(move, 0.3f);
        }

        
        anim.SetFloat("Forward", forward);

        cc.Move(move * Time.deltaTime);
    }

    void Run()
    {
        forward_Max = 1;
        player_Speed = state.runSpeed;
    }

    void ObjectGoUp(Vector3 distence, float maxDistance)
    {

        if (Physics.Raycast(transform.position, distence, maxDistance, (1 << 11)))
        {
            anim.Play("Climb_up");
            this.gameObject.GetComponent<PlayerMove>().enabled = false;
        }


    }

    void Movecle()
    {
        Vector3 inputMoveXZ = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        inputMoveXZ = myTransform.TransformDirection(inputMoveXZ);
        inputMoveXZ *= player_Speed;

        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.UpArrow))
        {
            if (forward <= forward_Max)
                forward = Mathf.Min(forward + (Time.deltaTime * animSpeed), forward_Max);
            else if (forward >= forward_Max)
                forward = Mathf.Max(forward - (Time.deltaTime * animSpeed), forward_Max);

            Quaternion cameraRotation = Camera.main.transform.rotation;
            cameraRotation.x = cameraRotation.z = 0;    //y축만 필요하므로 나머지 값은 0으로 바꾼다.
            myTransform.rotation = cameraRotation;

            if (move != Vector3.zero) //Quaternion.LookRotation는 (0,0,0)이 들어가면 경고를 내므로 예외처리 해준다.
            {
                Quaternion characterRotation = Quaternion.LookRotation(move);
                characterRotation.x = characterRotation.z = 0;
                model.rotation = Quaternion.Slerp(model.rotation, characterRotation, state.rotSpeed * Time.deltaTime);
            }

            move = inputMoveXZ;
        }
        else
        {
            forward = Mathf.Max(forward - (Time.deltaTime * animSpeed), 0);
            forward_Max = 0.5f;
            move = Vector3.zero;
        }
    }

    void pushMove_R()
    {
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
         {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                move = Vector3.left * state.pushSpeed;
                Push_Ray(move);
                if (forward <= 0.5f)
                    forward = Mathf.Min(forward + Time.deltaTime * animSpeed, 0.5f);
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                move = Vector3.right * state.pushSpeed;
                if (forward >= -0.5f)
                    forward = Mathf.Max(forward - Time.deltaTime * animSpeed, -0.5f);

            }
         }
         else
         {
             if (forward >= 0)
                 forward = Mathf.Max(forward - Time.deltaTime, 0);
             else if (forward <= 0)
                 forward = Mathf.Min(forward + Time.deltaTime, 0);

             move = Vector3.zero;
         }
    }

    void pushMove_L()
    {
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
        {
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                move = Vector3.left * state.pushSpeed;
                if (forward >= -0.5f)
                    forward = Mathf.Max(forward - Time.deltaTime * animSpeed, -0.5f);
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                move = Vector3.right * state.pushSpeed;
                Push_Ray(move);
                if (forward <= 0.5f)
                    forward = Mathf.Min(forward + Time.deltaTime * animSpeed, 0.5f);
            }

        }
        else
        {
            if (forward >= 0)
                forward = Mathf.Max(forward - Time.deltaTime, 0);
            else if (forward <= 0)
                forward = Mathf.Min(forward + Time.deltaTime, 0);

            move = Vector3.zero;
        }
    }

    void pushMove_B()
    {
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                move = Vector3.forward * state.pushSpeed;
                Push_Ray(move);
                if (forward <= 0.5f)
                    forward = Mathf.Min(forward + Time.deltaTime * animSpeed, 0.5f);
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            {
                move = Vector3.back * state.pushSpeed;
                if (forward >= -0.5f)
                    forward = Mathf.Max(forward - Time.deltaTime * animSpeed, -0.5f);
            }
        }
        else
        {
            if (forward >= 0)
                forward = Mathf.Max(forward - Time.deltaTime, 0);
            else if (forward <= 0)
                forward = Mathf.Min(forward + Time.deltaTime, 0);

            move = Vector3.zero;
        }
    }

    void pushMove_F()
    {
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
        {
            if (Input.GetKey(KeyCode.UpArrow))
            {
                move = Vector3.forward * state.pushSpeed;
                if (forward >= -0.5f)
                    forward = Mathf.Max(forward - Time.deltaTime * animSpeed, -0.5f);
            }
            else if (Input.GetKey(KeyCode.DownArrow))
            { 
                move = Vector3.back * state.pushSpeed;
                Push_Ray(move);
                if (forward <= 0.5f)
                    forward = Mathf.Min(forward + Time.deltaTime * animSpeed, 0.5f);
            }
        }
        else
        {
            if (forward >= 0)
                forward = Mathf.Max(forward - Time.deltaTime, 0);
            else if (forward <= 0)
                forward = Mathf.Min(forward + Time.deltaTime, 0);

            move = Vector3.zero;
        }
    }

    // 모든이동의 특정값일때 이동이불가능하게해야 현실감있어짐

    void Push_Ray(Vector3 direction)
    {
        float lange = 1.5f;
        // 해당 방향으로 ray를쏴서 앞에벽이있다면 이동이불가능하게 만든다.

        if (Physics.Raycast(this.transform.position, direction, out RaycastHit hit, lange, (-1) - (1 << 11) & (-1) - (1 << 2) & (-1) - (1 << 5 )))
        {
            Debug.Log(hit.transform.gameObject.name);
            move = Vector3.zero;
        }
    }

    private void OnDisable()
    {
        forward = 0;
        anim.SetFloat("Forward", 0);
    }
}
