﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PasswordObject : MonoBehaviour
{
    public int objectNumber;
}
