﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class PasswordPuzzleManager : MonoBehaviour
{
    public Text inputText;

    public int[] truePassword = new int[4];
    public int[] inputPassword = new int[4];

    public GameObject logoObject, textObject;

    public bool clear;
    bool realClear;
    public Canvas mycanvas;
    GraphicRaycaster gr;
    PointerEventData ped;
    // Start is called before the first frame update
    void Start()
    {
        gr = mycanvas.GetComponent<GraphicRaycaster>();
        ped = new PointerEventData(null);
        for (int i = 0; i < 4; i++) {
            inputPassword[i] = -1;
                }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.mousePosition != Vector3.zero)
        {
            ped.position = Input.mousePosition;

            List<RaycastResult> results = new List<RaycastResult>(); // 여기에 히트 된 개체 저장
            gr.Raycast(ped, results);


            if (results.Count != 0 && results[0].gameObject.transform.parent.gameObject.GetComponent<PasswordObject>())
            {
                
                if (Input.GetMouseButtonDown(0))
                {
                    if (results[0].gameObject.transform.parent.gameObject.GetComponent<PasswordObject>() && realClear == false)
                    {
                        InputCheck(results[0].gameObject.transform.parent.gameObject.GetComponent<PasswordObject>().objectNumber);
                        results[0].gameObject.transform.parent.gameObject.transform.GetChild(0).gameObject.SetActive(false);
                        results[0].gameObject.transform.parent.gameObject.transform.GetChild(1).gameObject.SetActive(true);
                    }
                }
                else if (Input.GetMouseButtonUp(0))
                {
                    results[0].gameObject.transform.parent.gameObject.transform.GetChild(1).gameObject.SetActive(false);
                    results[0].gameObject.transform.parent.gameObject.transform.GetChild(0).gameObject.SetActive(true);
                }
            }


        }
        
    }

    void TextUpdate()
    {
        inputText.text = (inputPassword[0] + "" + inputPassword[1] + "" + inputPassword[2] + ""+inputPassword[3]);
        inputText.text = inputText.text.Replace("-1", "");
        logoObject.transform.GetChild(0).gameObject.SetActive(true);
        logoObject.transform.GetChild(1).gameObject.SetActive(false);
        textObject.transform.GetChild(0).gameObject.SetActive(false);
        textObject.transform.GetChild(1).gameObject.SetActive(false);
        textObject.transform.GetChild(2).gameObject.SetActive(true);
    }

    void InputCheck(int type)
    {
        MapSound_0.GetInstance().eventSound_0_Start();
        Debug.Log("버튼");
        if (type == -1)
        {
            int i = 3;
            while (i >= 0)
            {
                if (inputPassword[i] != -1)
                {
                    inputPassword[i] = -1;
                    break;
                }
                i--;
            }
            TextUpdate();
        } else if (type == -2)
        {
            bool check = true;
            for(int i = 0; i <4; i++)
            {
                if(inputPassword[i] != truePassword[i])
                {
                    check = false;
                }
            }

            if (check)
            {
                for (int i = 0; i < 4; i++)
                {
                    inputPassword[i] = -1;
                }
                inputText.text = "";
                logoObject.transform.GetChild(0).gameObject.SetActive(false);
                logoObject.transform.GetChild(1).gameObject.SetActive(true);
                textObject.transform.GetChild(1).gameObject.SetActive(true);
                textObject.transform.GetChild(2).gameObject.SetActive(false);
                Debug.Log("퍼즐클리어");
                MapSound_0.GetInstance().eventSound_1_Start();
                StartCoroutine("Clear");
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    inputPassword[i] = -1;
                }
                inputText.text = "";
                textObject.transform.GetChild(0).gameObject.SetActive(true);
                textObject.transform.GetChild(2).gameObject.SetActive(false);
                Debug.Log("퍼즐틀림");
                MapSound_0.GetInstance().eventSound_2_Start();
            }
        }
        else {
            int i = 0;
            while (i<4)
            {
                if (inputPassword[i] == -1)
                {
                    inputPassword[i] = type;
                    break;
                }
                i++;
            }
            TextUpdate();
        }
    }

    IEnumerator Clear()
    {
        realClear = true;
        yield return new WaitForSeconds(1);
        clear = true;
    }
}
