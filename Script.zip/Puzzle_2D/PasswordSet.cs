﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PasswordSet : MonoBehaviour
{
    public bool puzzleSet;
    public GameObject passwordPuzzle;

    Vector3 scaleValue;
    Vector3 positionValue;
    GameObject Event;

    private void Start()
    {
        Event = GameObject.Find("AIObject");
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (Input.GetKeyDown(KeyCode.Z))
            {
                if (puzzleSet)
                {
                    StartCoroutine("UIOFF");
                }
                else if(puzzleSet == false && Event.GetComponent<AICharacter>().enabled == true)
                {
                    puzzleSet = true;
                    passwordPuzzle.SetActive(true);
                    UION();
                }
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            
            StartCoroutine("UIOFF");
        }
    }


    private void Update()
    {
        if (puzzleSet)
        {
            passwordPuzzle.transform.GetChild(0).GetChild(0).localScale = Vector3.Lerp(passwordPuzzle.transform.GetChild(0).GetChild(0).localScale, scaleValue, 10 * Time.deltaTime);
            passwordPuzzle.transform.GetChild(0).GetChild(0).localPosition = Vector3.Lerp(passwordPuzzle.transform.GetChild(0).GetChild(0).localPosition, positionValue, 10 * Time.deltaTime);
        }

        if(passwordPuzzle.GetComponent<PasswordPuzzleManager>().clear == true)
        {
            StartCoroutine("UIOFF");
        }
    }

    void UION()
    {
        passwordPuzzle.transform.parent = Camera.main.transform;
        scaleValue = new Vector3(0.8f,0.8f,0.8f);
        positionValue = new Vector3(0, 0, 0);
    }

    IEnumerator UIOFF()
    {
        if (puzzleSet)
        {
            scaleValue = new Vector3(0, 0, 0);
            positionValue = new Vector3(0, -1000, 0);
            yield return new WaitForSeconds(1f);
            puzzleSet = false;
            passwordPuzzle.SetActive(false);
            passwordPuzzle.transform.parent = null;
        }
    }
}
