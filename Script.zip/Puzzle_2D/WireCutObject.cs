﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WireCutObject : MonoBehaviour
{
    public int objectNumber;
}
