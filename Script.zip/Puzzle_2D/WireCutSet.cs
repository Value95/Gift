﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WireCutSet : MonoBehaviour
{
    public bool puzzleSet;
    public GameObject wirecutPuzzle;
    public GameObject textObject;
    Vector3 scaleValue;
    Vector3 positionValue;
    public bool textSet;

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (Input.GetKeyUp(KeyCode.Z)) {

                if (puzzleSet)
                {
                    puzzleSet = false;
                    StartCoroutine("UIOFF");
                    Debug.Log("1");
                }


               else if (other.GetComponent<PlayerFSM>().cutter == true)
                {
                    if (puzzleSet == false)
                    {
                        puzzleSet = true;
                        wirecutPuzzle.SetActive(true);
                        UION();
                    }
                }
                else if(other.GetComponent<PlayerFSM>().interactionObj == null && textSet == false)
                {
                    textSet = true;
                    textObject.GetComponent<UITextMessage>().textString = "감전 될 것 같아";
                    textObject.GetComponent<UITextMessage>().x_MAX = 9;
                    textObject.GetComponent<UITextMessage>().TextOn();
                    Debug.Log("3");
                }
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine("UIOFF");
        }
    }


    private void Update()
    {
        if (puzzleSet)
        {
            wirecutPuzzle.transform.GetChild(0).GetChild(0).localScale = Vector3.Lerp(wirecutPuzzle.transform.GetChild(0).GetChild(0).localScale, scaleValue, 10 * Time.deltaTime);
            wirecutPuzzle.transform.GetChild(0).GetChild(0).localPosition = Vector3.Lerp(wirecutPuzzle.transform.GetChild(0).GetChild(0).localPosition, positionValue, 10 * Time.deltaTime);
        }

        if (wirecutPuzzle.GetComponent<WireCutPuzzleManager>().clear == true)
        {
            StartCoroutine("UIOFF");
        }
        
    }

    void UION()
    {
        wirecutPuzzle.transform.parent = Camera.main.transform;
        scaleValue = new Vector3(0.8f, 0.8f, 0.8f);
        positionValue = new Vector3(0, 0, 0);
    }

    IEnumerator UIOFF()
    {
        scaleValue = new Vector3(0, 0, 0);
        positionValue = new Vector3(0, -1000, 0);
        yield return new WaitForSeconds(1f);
        puzzleSet = false;
        wirecutPuzzle.SetActive(false);
        wirecutPuzzle.transform.parent = null;
        Debug.Log("8");
    }
}
