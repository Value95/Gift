﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.EventSystems;

public class WireCutPuzzleManager : MonoBehaviour
{

    GraphicRaycaster gr;
    PointerEventData ped;
    public GameObject[] line = new GameObject[5];
    public int[] lineValue = new int[5];
    public bool clear;
    public GameObject playerObject;

    public GameObject effect;

    public Canvas mycanvas;
    // Start is called before the first frame update
    void Start()
    {
        gr = mycanvas.GetComponent<GraphicRaycaster>();
        ped = new PointerEventData(null);


        playerObject = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {

        
        RayCheck();
        WireCheck();
       
    }

    void RayCheck()
    {
        if (Input.mousePosition != Vector3.zero)
        {
            ped.position = Input.mousePosition;

            List<RaycastResult> results = new List<RaycastResult>(); // 여기에 히트 된 개체 저장
            gr.Raycast(ped, results);

            if (results.Count != 0 && results[0].gameObject.transform.parent.gameObject.GetComponent<WireCutObject>())
            {
                if (lineValue[results[0].gameObject.transform.parent.gameObject.GetComponent<WireCutObject>().objectNumber] == 0)
                {
                    RenderChange(results[0].gameObject.transform.parent.gameObject, 1);
                }


                if (Input.GetMouseButtonDown(0))
                {
                    lineValue[results[0].gameObject.transform.parent.gameObject.GetComponent<WireCutObject>().objectNumber] = 1;
                    RenderChange(results[0].gameObject.transform.parent.gameObject, 2);
                    MapSound_0.GetInstance().eventSound_3_Start();
                    
                }

            }
            else
            {
                RenderOrign();
            }
            
        }
    }
    void RenderOrign()
    {
        for (int i = 0; i < 5; i++)
        {
            if (lineValue[i] == 0)
            {
                RenderChange(line[i], 0);
            }
        }
    }
    void RenderChange(GameObject obj, int num)
    {
        obj.transform.GetChild(0).gameObject.SetActive(false);
        obj.transform.GetChild(1).gameObject.SetActive(false);
        obj.transform.GetChild(2).gameObject.SetActive(false);

        obj.transform.GetChild(num).gameObject.SetActive(true);
    }

    void Fail()
    {
        GameObject.Find("waterDeath").GetComponent<DeathWaterEvent>().enabled = true;
        effect.GetComponent<ParticleSystem>().Play();
        this.GetComponent<WireCutPuzzleManager>().enabled = false;
        this.gameObject.SetActive(false);
    }
    

    void WireCheck()
    {
        if(lineValue[2] == 1)
        {
            Fail();
        }
        if (lineValue[4] == 1)
        {
            Fail();
        }

        if(lineValue[0] == 1 && lineValue[1] == 1&& lineValue[3] == 1 && clear == false)
        {
            StartCoroutine("Clear");

         }
    }

    IEnumerator Clear()
    {
        yield return new WaitForSeconds(1);
        Debug.Log("clear2");
        clear = true;
        MapSound_0.GetInstance().Electricit_Stop();
    }
}
