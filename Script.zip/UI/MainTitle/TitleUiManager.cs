﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

enum ui_name
{
    start,
    option,
    exit
}

public class TitleUiManager : MonoBehaviour
{
    bool sound = true;

    public List<Sprite> ui_sprite = new List<Sprite>();
    public List<Image> ui = new List<Image>();

    public Canvas mycanvas; // raycast가 될 캔버스
    GraphicRaycaster gr;
    PointerEventData ped;
    // Start is called before the first frame update
    void Start()
    {
        gr = mycanvas.GetComponent<GraphicRaycaster>();
        ped = new PointerEventData(null);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.mousePosition != Vector3.zero)
        {
            ped.position = Input.mousePosition;

            List<RaycastResult> results = new List<RaycastResult>(); // 여기에 히트 된 개체 저장
            gr.Raycast(ped, results);

            Change_UI(results[0].gameObject.name.ToString());
        }

        
    }

    void Change_UI(string name)
    {
        switch (name)
        {
            case "START":
                if(sound)
                {
                    sound = false;
                    UiSound.GetInstance().Select_Sound_Start();
                }
                ui[(int)ui_name.start].sprite = ui_sprite[1];
                ui[(int)ui_name.option].sprite = ui_sprite[2];
                ui[(int)ui_name.exit].sprite = ui_sprite[4];
                break;
            case "OPTION":
                if (sound)
                {
                    sound = false;
                    UiSound.GetInstance().Select_Sound_Start();
                }
                ui[(int)ui_name.start].sprite = ui_sprite[0];
                ui[(int)ui_name.option].sprite = ui_sprite[3];
                ui[(int)ui_name.exit].sprite = ui_sprite[4];
                break;
            case "EXIT":
                if (sound)
                {
                    sound = false;
                    UiSound.GetInstance().Select_Sound_Start();
                }
                ui[(int)ui_name.start].sprite = ui_sprite[0];
                ui[(int)ui_name.option].sprite = ui_sprite[2];
                ui[(int)ui_name.exit].sprite = ui_sprite[5];
                break;
            default:
                sound = true;
                break;
        }
    }
}

    // 레이에 맞는 ui의 이미지를바꾸어준다.

    // 켄버스의 레이를게속쏴서 물체를판단
    // 해당물체에맞는 ui로변경