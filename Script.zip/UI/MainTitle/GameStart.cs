﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameStart : MonoBehaviour
{
    // 옵션들이사라진다
    // 메인화면이라사라진다
    // 뷰전환
    public List<Image> ui = new List<Image>();
    public Image title;

    bool start = false;
    bool titlestart = true;

    // Start is called before the first frame update

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (start)
        {
            foreach (var ui_Image in ui)
            {
                if (titlestart)
                {
                    titlestart =  EventHelp.FadeOut(ui_Image);
                    if (!titlestart)
                    {
                        EventHelp.FadeOut(ui[1]);
                        EventHelp.FadeOut(ui[2]);
                    }
                }
                else if(!titlestart)
                {
                    if(!EventHelp.FadeOut(title))
                    {
                        EventHelp.NextScene(1);
                        UiSound.GetInstance().BackGround_Bgm_Game_Stop();
                        start = false;
                    }
                }
            }
        }







        if (Input.GetKeyDown(KeyCode.F1))
        {
            EventHelp.NextScene(1);
            UiSound.GetInstance().BackGround_Bgm_Game_Stop();
        }
        if (Input.GetKeyDown(KeyCode.F2))
        {
            EventHelp.NextScene(2);
            UiSound.GetInstance().BackGround_Bgm_Game_Stop();
        }
        if (Input.GetKeyDown(KeyCode.F3))
        {
            EventHelp.NextScene(3);
            UiSound.GetInstance().BackGround_Bgm_Game_Stop();
        }
    }

    public void StartExecution()
    {
        start = true;
        UiSound.GetInstance().Click_Sound_Start();
    }

    public void GameExit()
    {
        Application.Quit();
    }




}
