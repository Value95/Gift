﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float movementSpeed;
    public bool targetCheck;
    public bool backCheck;

    GameObject[] effectObject =  new GameObject[2];
    Vector3 startPos;
    public GameObject DeahtSpotlightEvent;
    GameObject playerObject;
    Vector3 playerPos;
    void Start()
    {
        playerObject = GameObject.Find("Player");
        effectObject[0] = transform.GetChild(0).gameObject;
        effectObject[1] = transform.GetChild(1).gameObject;
        startPos = gameObject.transform.position;
        playerPos = playerObject.transform.position;
        playerPos.y += 0.7f;
        Destroy(gameObject, 10);
    }

    // Update is called once per frame
    void Update()
    {
        if (targetCheck == false)
            transform.position = Vector3.MoveTowards(transform.position, playerPos, movementSpeed * Time.deltaTime);


        //if(backCheck == true)
        //    transform.Translate(Vector3.forward * Time.deltaTime * -movementSpeed);

        //if(Vector3.Distance(gameObject.transform.position, startPos) < 1f)
        //{
        //    backCheck = false;
        //}

        if (Vector3.Distance(playerPos, gameObject.transform.position) < 0.3f)
        {
            if (targetCheck == false)
            {
                playerObject.GetComponent<PlayerFSM>().playerState = Player_State.Death;
                DeahtSpotlightEvent.GetComponent<DeathEventName>().onEvent();
                targetCheck = true;
                // StartCoroutine("Back");
            }
        }
    }
    
    

    IEnumerator Back()
    {
        yield return new WaitForSeconds(2f);
        backCheck = true;
        effectObject[0].SetActive(false);
        effectObject[1].SetActive(true);
        //move.Death();
    }
    

}
