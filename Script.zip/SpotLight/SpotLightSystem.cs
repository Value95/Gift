﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpotLightSystem : MonoBehaviour
{
    public enum LightType
    {
        White,
        Red,
        Blue,
        Yellow
    }
    public LightType lightType;

    public GameObject bulletPrefab;


    public GameObject targetObject;
    public float targetMovementSpeed;
    public float targetMoveDelayTime;
    public int targetPointCountMAX;
    public GameObject[] targetMovePoint;

    public float lightMovementSpeed;
    public float lightMoveDelayTime;
    public GameObject[] lightMovePoint;




    public float targetMoveTime, lightMoveTime;
    GameObject playerObject, rayCheckObject;
    Ray ray;
    RaycastHit hit;
    bool shot, targetMove, lightMove;
    Vector3 targetPos;
    Camera cam;
    int targetPointCount;
    public GameObject DeahtSpotlightEvent;
    public bool lightOn;

    // Start is called before the first frame update
    void Start()
    {
        playerObject = GameObject.Find("Player");
        rayCheckObject = transform.GetChild(0).gameObject;
        cam = GetComponent<Camera>();
        ray = new Ray();
        LightColorChange();
    }


    // Update is called once per frame
    void Update()
    {
        TargetMove();
        LightMove();


        if (shot == false)
            Check();


        if (Vector3.Distance(targetObject.transform.position, playerObject.transform.position) < 10)
        {
            if (lightOn == false)
            {
                MapSound_0.GetInstance().LightOn_Start();
                lightOn = true;
            }
        }
        else
        {
            if (lightOn == true)
            {
                MapSound_0.GetInstance().LightOn_Stop();
                lightOn = false;
            }
        }


    }
    public void Check()
    {
        {
            Vector3 viewPos = cam.WorldToViewportPoint(playerObject.transform.position);
            if (viewPos.z > 0 && viewPos.x > 0 && viewPos.x < 1 && viewPos.y > 0 && viewPos.y < 1)
            {
                Vector3 tPos = playerObject.transform.position;
                tPos.y += 1;
                rayCheckObject.transform.LookAt(tPos);


                ray.origin = gameObject.transform.position;
                ray.direction = rayCheckObject.transform.forward;
                int mask = 1 << LayerMask.NameToLayer("Collider") | 1 << LayerMask.NameToLayer("Ignore Raycast");
                mask = ~mask;
                if (Physics.Raycast(ray.origin, ray.direction, out hit, 50, mask))
                {
                    if (hit.collider.gameObject.CompareTag("Player"))
                    {

                        if (playerObject.GetComponent<PlayerFSM>().playerState != Player_State.Concealment)
                        {
                            switch (lightType)
                            {
                                case LightType.White:

                                    break;
                                case LightType.Red:
                                    targetPos = hit.transform.position;
                                    Fire();
                                    break;
                                case LightType.Blue:
                                    targetPos = hit.transform.position;
                                    Fire();
                                    break;
                                case LightType.Yellow:
                                    targetPos = hit.transform.position;
                                    Fire();
                                    break;
                            }
                        }

                    }
                }
            }
        }
    }

    void TargetMove()
    {
        if (shot == false)
        {
            if (targetMoveTime > 0)
            {
                targetMoveTime -= Time.deltaTime;
            }
            else
            {
                if (targetMove)
                {
                    targetObject.transform.position = Vector3.MoveTowards(targetObject.transform.position, targetMovePoint[targetPointCount].transform.position, targetMovementSpeed * Time.deltaTime);
                    if (Vector3.Distance(targetObject.transform.position, targetMovePoint[targetPointCount].transform.position) < 0.1f)
                    {
                        if (targetPointCount >= targetPointCountMAX - 1)
                        {
                            targetMove = false;
                            targetPointCount--;
                        }
                        else
                        {
                            targetPointCount++;
                        }
                        targetMoveTime = targetMoveDelayTime;
                    }
                }
                else
                {
                    targetObject.transform.position = Vector3.MoveTowards(targetObject.transform.position, targetMovePoint[targetPointCount].transform.position, targetMovementSpeed * Time.deltaTime);
                    if (Vector3.Distance(targetObject.transform.position, targetMovePoint[targetPointCount].transform.position) < 0.1f)
                    {
                        if (targetPointCount <= 0)
                        {
                            targetMove = true;
                            targetPointCount++;
                        }
                        else
                        {
                            targetPointCount--;
                        }
                        targetMoveTime = targetMoveDelayTime;
                    }
                }
            }
        }
        else
        {
            targetObject.transform.position = Vector3.Lerp(targetObject.transform.position, targetPos, targetMovementSpeed * Time.deltaTime);
        }
        transform.LookAt(targetObject.transform);
    }


    void LightMove()
    {
        if (shot == false)
        {
            if (lightMoveTime > 0)
            {
                lightMoveTime -= Time.deltaTime;
            }
            else
            {
                if (lightMove)
                {
                    gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, lightMovePoint[0].transform.position, lightMovementSpeed * Time.deltaTime);
                    if (Vector3.Distance(gameObject.transform.position, lightMovePoint[0].transform.position) < 0.1f)
                    {
                        lightMove = false;
                        lightMoveTime = lightMoveDelayTime;
                    }
                }
                else
                {
                    gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, lightMovePoint[1].transform.position, lightMovementSpeed * Time.deltaTime);
                    if (Vector3.Distance(gameObject.transform.position, lightMovePoint[1].transform.position) < 0.1f)
                    {
                        lightMove = true;
                        lightMoveTime = lightMoveDelayTime;
                    }
                }
            }
        }
    }


    void Fire()
    {
        shot = true;
        playerObject.GetComponent<PlayerMove>().enabled = false;
        GameObject bulletObject = Instantiate(bulletPrefab);
        bulletObject.GetComponent<Bullet>().DeahtSpotlightEvent = DeahtSpotlightEvent;
        bulletObject.transform.position = gameObject.transform.position;
        bulletObject.transform.LookAt(new Vector3(playerObject.transform.position.x, playerObject.transform.position.y + 1, playerObject.transform.position.z));
        //playerObject.GetComponent<PlayerFSM>().anim.SetInteger("MoveType", (int)MoveType.Idle);
        StartCoroutine("delayReturn");
        MapSound_0.GetInstance().Watchtower_BulletSound_Start();
    }

    void LightColorChange()
    {
        switch (lightType)
        {
            case LightType.White:
                GetComponent<Light>().color = Color.white;
                break;
            case LightType.Red:
                GetComponent<Light>().color = Color.red;
                break;
            case LightType.Blue:
                GetComponent<Light>().color = Color.blue;
                break;
            case LightType.Yellow:
                GetComponent<Light>().color = Color.yellow;
                break;
        }

    }

    IEnumerator delayReturn()
    {
        yield return new WaitForSeconds(0.3f);
        //playerObject.GetComponent<PlayerFSM>().playerState = Player_State.Death;
        //DeahtSpotlightEvent.GetComponent<DeathEventName>().onEvent();
        yield return new WaitForSeconds(3f);
        shot = false;
    }
}
