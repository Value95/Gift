﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// HelpClass
public static class EventHelp
{
    
    // 타겟지점까지 일정한속도로 이동
    public static bool targetMove(this GameObject mygameObjct, GameObject player, Transform target)
    {
        Vector3 vec = mygameObjct.transform.position;

        Vector3 vectorTarget = target.position;
        vectorTarget.y = player.transform.position.y;
        player.transform.position = Vector3.MoveTowards(player.transform.position, vectorTarget, 5 * Time.deltaTime);

        //수정필요
        vec.x = player.transform.GetChild(0).transform.localPosition.x;
        player.transform.GetChild(0).transform.LookAt(vec);

        if (player.transform.position == vectorTarget)
            return true;

        return false;
    }

    public static bool targetMove_1(this GameObject mygameObjct, GameObject player, Transform target)
    {
        Vector3 vec = mygameObjct.transform.position;

        Vector3 vectorTarget = target.position;
        vectorTarget.y = player.transform.position.y;
        player.transform.position = Vector3.MoveTowards(player.transform.position, vectorTarget, 5 * Time.deltaTime);

        //수정필요
        vec.x = player.transform.GetChild(0).transform.position.x;
        player.transform.GetChild(0).transform.LookAt(vec);
        Quaternion temp = player.transform.GetChild(0).transform.rotation;
        temp.x = 0;
        player.transform.GetChild(0).transform.rotation = temp;

        if (player.transform.position == vectorTarget)
            return true;

        return false;
    }

    // 페이드인 페이드아웃
    public static bool Fadein(Image Fade)
    {
        // 알파값올리기
        float speed = 0.3f;

        Color temp = Fade.color;
        temp.a = Mathf.Min(temp.a + (speed * Time.deltaTime), 1);
        Fade.color = temp;

        if (Fade.color.a == 1)
            return false;
        return true;
    }

    public static bool FadeOut(Image Fade)
    {
        // 알파값내리기
        float speed = 0.6f;

        Color temp = Fade.color;
        temp.a = Mathf.Max(temp.a - (speed * Time.deltaTime), 0);
        Fade.color = temp;

        if (Fade.color.a == 0)
            return false;
        return true;
    }

    public static void NextScene(int nextSceneNumber)
    {
        SceneManager.LoadSceneAsync(nextSceneNumber);
    }
}
