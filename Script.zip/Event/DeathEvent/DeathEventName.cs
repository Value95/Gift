﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum DeathName
{
    Spotlight,
    Extraman,
    Water
}

public class DeathEventName : MonoBehaviour
{
    public DeathName name;
    public GameObject player;
    [HideInInspector] public PlayerMove move;

    public Image fade;
    [HideInInspector] public bool fade_InOut = true;

    public void Start()
    {
        move = player.GetComponent<PlayerMove>();
    }

    public void onEvent()
    {
        switch(name)
        {
            case DeathName.Spotlight:
                GetComponent<DeathSpotlightEvent>().enabled = true;
                break;
            case DeathName.Extraman:
                GetComponent<DeathExtramanEvent>().enabled = true;
                break;
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if(other.tag == "Player")
        {
            switch (name)
            {
                case DeathName.Extraman:
                    GetComponent<DeathExtramanEvent>().enabled = true;
                    break;
                case DeathName.Water:
                    GetComponent<DeathWaterEvent>().enabled = true;
                    break;
            }
        }
    }
}
