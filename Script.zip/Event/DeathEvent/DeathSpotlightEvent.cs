﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathSpotlightEvent : MonoBehaviour
{
    DeathEventName deathevent;

    public Transform spawn_Player_Pos;
    public Transform spawn_Box_Pos;

    public GameObject box;
    public GameObject boxs;

    private void Awake()
    {
        deathevent = this.GetComponent<DeathEventName>();
    }

    private void OnEnable()
    {
        // 쓰러지기애니메이션
        deathevent.move.anim.Play("Walk_Shock_Death");
        deathevent.player.GetComponent<PlayerFSM>().ChScript(Player_State.Death);

    }

    // Update is called once per frame
    void Update()
    {
        if (deathevent.fade_InOut)
        {
            deathevent.fade_InOut = EventHelp.Fadein(deathevent.fade);
            if (!deathevent.fade_InOut)
            {
                //deathevent.GetComponent<PlayerFSM>().ChScript(Player_State.Death);
                deathevent.player.transform.position = spawn_Player_Pos.position;
                box.transform.parent = boxs.transform;
                box.transform.position = spawn_Box_Pos.position;
                // 가로등 다시 작동하게
            }
            return;
        }

        if (!EventHelp.FadeOut(deathevent.fade))
        {
            this.GetComponent<DeathSpotlightEvent>().enabled = false;
            deathevent.move.enabled = true;
            deathevent.fade_InOut = true;
            deathevent.player.GetComponent<PlayerFSM>().ChScript(Player_State.Idle);
        }
    }
}
