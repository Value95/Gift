﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OtherObjectReset : MonoBehaviour
{
    public GameObject AI;
    

    [System.Serializable]
    public struct Set_1
    {
        public GameObject evnetObject;
        public GameObject door;
        public GameObject AI_Light;
    }

    [System.Serializable]
    public struct Set_2
    {
        public GameObject evnetObject;
    }

    public Set_1 reset_1 = new Set_1();
    public Set_2 reset_2 = new Set_2();
    


    public void ResetOther(int num)
    {
        switch (num)
        {
            case 1:
                Reset_1();
                break;
        }
    }
    

    void Reset_1()
    {
        
        AI.transform.position = new Vector3(62, 0, 1.7f);
        AI.GetComponent<AICharacter>().AI_STATE = AIState.Patrol;
        AI.GetComponent<AICharacter>().enabled = false;
        reset_1.AI_Light.SetActive(false);
        reset_1.evnetObject.GetComponent<Scene2_EventManager>().eventNumber = 0;
        reset_1.door.transform.eulerAngles = new Vector3(-90, 0, 16.754f);
        
    }
}
