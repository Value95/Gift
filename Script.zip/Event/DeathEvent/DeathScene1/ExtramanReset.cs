﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExtramanReset : MonoBehaviour
{
    public GameObject AI;


    public void ResetAI()
    {
        AI.GetComponent<AICharacter>().AI_STATE = AIState.Patrol;
    }
}
