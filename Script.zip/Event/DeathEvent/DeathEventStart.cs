﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathEventStart : MonoBehaviour
{
    public DeathEventName deathevent;
    public DeathExtramanEvent deathEvent;

    public void DeathExtramanEventStart()
    {
        if(deathEvent)
        {
            deathEvent.start = true;
            deathevent.move.enabled = false;
            MapSound_0.GetInstance().Extraman_BulletSound_Start();
            deathevent.move.anim.Play("Walk_Shock_Death");
            deathEvent.extraman.SetBool("Shooting", false);
        }
    }
}
