﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeathWaterEvent : MonoBehaviour
{
    DeathEventName deathevent; // 죽을때발생되는 공통적인 오브젝트를둔곳


    bool state = true;
    private void Awake()
    {
        deathevent = this.GetComponent<DeathEventName>();
    }

    private void OnEnable()
    {
        deathevent.move.enabled = false;
        MapSound_0.GetInstance().eventSound_4_Start();
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (state)
        {
            if (deathevent.fade_InOut)
            {
                deathevent.fade_InOut = EventHelp.Fadein(deathevent.fade);
                
            }

            if (!deathevent.fade_InOut)
            {
                SceneManager.LoadSceneAsync(3);
                MapSound_0.GetInstance().Electricit_Stop();
                state = false;

            }
        }
    }

    /// 1. 즉는애니메이션
    /// 2. 페이드인 페이드아웃
    /// 3. 씬 다시 시작
}
