﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathExtramanEvent : MonoBehaviour
{
    DeathEventName deathevent; // 죽을때발생되는 공통적인 오브젝트를둔곳

    public Concealment_Cabinet concealment_cabinet;

    public Transform spawn_Player_Pos;
    public Transform spawn_Box_Pos;

    public GameObject box;
    public GameObject boxs;

    public Animator extraman; // AI

    public GameObject effectpos;
    public GameObject effect;

    [HideInInspector] public bool start = false;
    private void Awake()
    {
        deathevent = this.GetComponent<DeathEventName>();
    }

    private void OnEnable()
    {
        extraman.SetBool("Shooting", true);
        GameObject effectTemp = Instantiate(effect, effectpos.transform.position, Quaternion.identity);
        effectTemp.transform.parent = effectpos.transform;
        effectTemp.transform.localPosition = Vector3.zero;
        Destroy(effectTemp, 0.8f);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (start)
        {   
            if (deathevent.fade_InOut)
            {
                deathevent.fade_InOut = EventHelp.Fadein(deathevent.fade);

                if (!deathevent.fade_InOut)
                {
                    MapSound_0.GetInstance().ChaseOn_Stop();
                    MapSound_0.GetInstance().Background_Bgm_Game_Start();

                    deathevent.player.GetComponent<PlayerFSM>().ChScript(Player_State.Idle);
                    deathevent.player.transform.position = spawn_Player_Pos.position;
                    if (box)
                    {
                        box.transform.parent = boxs.transform;
                        box.transform.position = spawn_Box_Pos.position;
                    }

                    if(concealment_cabinet)
                        concealment_cabinet.LockerEnd();
                    
                }
                return;
            }

            if (!EventHelp.FadeOut(deathevent.fade))
            {
                this.GetComponent<DeathExtramanEvent>().enabled = false;
                deathevent.fade_InOut = true;
                deathevent.move.enabled = true;
                start = false;

            }
        }
    }
}
