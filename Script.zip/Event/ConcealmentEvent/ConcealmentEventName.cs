﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ConcealmentName
{
    Cabinet
}


public class ConcealmentEventName : MonoBehaviour
{
    public PlayerMove move;
    public GameObject player;
    [HideInInspector] public Animator anim;

    public ConcealmentName name;

    private void Start()
    {
        anim = player.transform.GetChild(0).GetComponent<Animator>();
    }

    public void EventOn()
    {
        switch (name)
        {
            case ConcealmentName.Cabinet:
                GetComponent<Concealment_Cabinet>().enabled = true;
                break;
        }
    }

}
