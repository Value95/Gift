﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class Concealment_Cabinet : MonoBehaviour
{
    ConcealmentEventName concealmentEvent;

    public Transform target;

    public bool targetmoveCheck = true;

    // Start is called before the first frame update
    void Start()
    {
        concealmentEvent = this.GetComponent<ConcealmentEventName>();
    }

    private void OnEnable()
    {
        targetmoveCheck = true;
    }

    // Update is called once per frame
    void Update()
    {
        // 해당위치까지이동
        if(targetmoveCheck)
        {
            if(EventHelp.targetMove_1(this.gameObject, concealmentEvent.player, target))
            {
                targetmoveCheck = false;
                concealmentEvent.anim.Play("Cabinet_In");
                this.GetComponent<Animator>().Play("Cabinet_In");
                MapSound_0.GetInstance().Cabinet_OnSound_Start();
            }
        }

        //z누르면 나오게
        if (concealmentEvent.anim.GetCurrentAnimatorStateInfo(0).IsName("Cabinet_In"))
        {
            if (concealmentEvent.anim.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.9f)
            {
                if(Input.GetKeyDown(KeyCode.Z))
                {
                    concealmentEvent.anim.SetBool("Concealment", true);
                    this.GetComponent<Animator>().Play("Cabinet_Out");
                    MapSound_0.GetInstance().Cabinet_OffSound_Start();
                }
            }
        }

        if (concealmentEvent.anim.GetCurrentAnimatorStateInfo(0).IsName("Cabinet_Out"))
        {
            if (concealmentEvent.anim.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.9f)
            {
                LockerEnd();
            }
        }
    }

    public void LockerEnd()
    {
        this.GetComponent<Concealment_Cabinet>().enabled = false;
        concealmentEvent.player.GetComponent<PlayerFSM>().ChScript(Player_State.Idle);
        concealmentEvent.move.enabled = true;
        targetmoveCheck = true;
    }
}



