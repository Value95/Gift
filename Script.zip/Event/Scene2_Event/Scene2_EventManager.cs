﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene2_EventManager : MonoBehaviour
{
    public int eventNumber;
    GameObject player;
    public GameObject AI, AI_Light;
    
    public GameObject door;
    public GameObject puzzle;
    public GameObject textObject, textObject2;
    public GameObject nextPos;
    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        switch (eventNumber)
        {
            case 0:
                if ((Vector3.Distance(player.transform.position, door.transform.position) < 4)){
                    eventNumber++;
                    StartCoroutine("AI_ON");
                }
                break;
            case 1:
                if(puzzle.GetComponent<PasswordPuzzleManager>().clear == true)
                {
                    
                    eventNumber++;
                    door.GetComponent<Animator>().SetBool("Open", true);
                    MapSound_0.GetInstance().Door_OnSound_Start();
                }
                break;
        }
    }


    IEnumerator AI_ON()
    {
        textObject2.GetComponent<UITextMessage>().textString = "무슨 소리가 들렸어";
        textObject2.GetComponent<UITextMessage>().x_MAX = 10;
        textObject2.GetComponent<UITextMessage>().TextOn();
        yield return new WaitForSeconds(4f);
        textObject2.GetComponent<UITextMessage>().textString = "뭐가 있나";
        textObject2.GetComponent<UITextMessage>().x_MAX = 5;
        textObject2.GetComponent<UITextMessage>().TextOn();
        yield return new WaitForSeconds(4f);
        AI.GetComponent<AICharacter>().enabled = true;
        AI_Light.SetActive(true);
        door.GetComponent<Animator>().SetBool("Open", true);
        MapSound_0.GetInstance().Door_OnSound_Start();
        yield return new WaitForSeconds(4f);
        door.GetComponent<Animator>().SetBool("Open", false);
        MapSound_0.GetInstance().Door_OffSound_Start();
        nextPos.transform.position = new Vector3(30, 0, 2);
    }
}
