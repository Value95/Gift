﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class BreakerUpEvent : MonoBehaviour
{
    ObjectEventName objEvent;
    // 차단기
    public GameObject breaker;

    // 이동타겟
    public Transform target;
    bool targetCheck = true;

    public PlayableDirector playableDirector;

    // Start is called before the first frame update
    void Start()
    {
        objEvent = GetComponent<ObjectEventName>();
        objEvent.playerMove.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(targetCheck)
        {
            if(EventHelp.targetMove(this.gameObject, objEvent.player, target))
            {
                targetCheck = false;
                MapSound_0.GetInstance().Breaker_UpSound_Start();
                Play();
            }
        }

        if (playableDirector.time >= 0.90f)
        {
            breaker.GetComponent<Animator>().Play("breakerUp");
            
        }

        if(breaker.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("breakerUp"))
        {
            if (breaker.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > 0.9f)
                SecordEnd();
        }
    }

    void SecordEnd()
    {
        objEvent.playerMove.enabled = true;
        breaker.GetComponent<BoxCollider>().enabled = false;
        this.GetComponent<BreakerUpEvent>().enabled = false;
    }

    public void Play()
    {
        playableDirector.Play();
    }
}

// 모든제어를 타임라인으로 넘기게 만들자