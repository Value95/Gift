﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClimbStairs : MonoBehaviour
{
    public GameObject player;
    public PlayerMove move;
    public Animator anim;
    public Transform target;

    bool start = false;
    // Update is called once per frame
    void Update()
    {
        if(start)
        {
            targetMove(target.gameObject, player, target.transform);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            startevent();
            start = true;
        }
    }

    void startevent()
    {
        move.enabled = false;
        anim.Play("Move");
        anim.SetFloat("Forward", 0.5f);
        anim.SetFloat("Sit", 0f);
    }

    void targetMove(GameObject mygameObjct, GameObject player, Transform target)
    {
        Vector3 vec = mygameObjct.transform.position;

        Vector3 vectorTarget = target.position;
        player.transform.position = Vector3.MoveTowards(player.transform.position, vectorTarget, 1 * Time.deltaTime);

        //수정필요
        player.transform.GetChild(0).transform.LookAt(vec);

        if (player.transform.position == vectorTarget)
            Destroy(player);
    }
}
