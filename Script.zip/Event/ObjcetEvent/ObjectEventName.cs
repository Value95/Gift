﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum ObjectName
{
    AntennaRepair = 1,
    BreakerUp,
    Cutter,
    Key
}


public class ObjectEventName : MonoBehaviour
{
    public ObjectName name;

    public PlayerMove playerMove;
    public GameObject player;
    [HideInInspector] public Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        anim = player.transform.GetChild(0).GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void EventOn()
    {
        switch(name)
        {
            case ObjectName.AntennaRepair:
                GetComponent<AntennaRepairEvent>().enabled = true;
                break;
            case ObjectName.BreakerUp:
                GetComponent<BreakerUpEvent>().enabled = true;
                break;
            case ObjectName.Cutter:
                GetComponent<CutterEvent>().enabled = true;
                break;
            case ObjectName.Key:
                GetComponent<KeyEvent>().enabled = true;
                break;
        }
    }
}
