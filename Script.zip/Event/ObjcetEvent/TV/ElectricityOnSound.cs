﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElectricityOnSound : MonoBehaviour
{
    public GameObject player;

    public bool soundOn = false;
    // Update is called once per frame
    void Update()
    {
        if (Vector3.Distance(player.transform.position, this.transform.position) >= 5)
        {
            if (!soundOn)
            {
                MapSound_0.GetInstance().Electricit_Start();
                soundOn = true;
            }
        }
        else
        {
            MapSound_0.GetInstance().Electricit_Start();
            soundOn = false;
        }
    }
}
