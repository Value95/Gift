﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyEvent : MonoBehaviour
{
    ObjectEventName objEvent;

    public Transform target;
    bool targetCheck = true;

    // Start is called before the first frame update
    void Start()
    {
        objEvent = GetComponent<ObjectEventName>();
    }

    // Update is called once per frame
    void Update()
    {
        if (targetCheck)
        {
            if (EventHelp.targetMove(this.gameObject, objEvent.player, target))
            {
                targetCheck = false;
                objEvent.playerMove.enabled = false;
                objEvent.anim.Play("Card_Take");
            }
            return;
        }

        if (objEvent.anim.GetCurrentAnimatorStateInfo(0).IsName("Card_Take"))
        {
            if (objEvent.anim.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.88f)
                ThierdEnd();
        }
    }

    void ThierdEnd()
    {
        objEvent.playerMove.enabled = true;
        objEvent.player.GetComponent<PlayerFSM>().key = true;
        Destroy(this.gameObject);
    }
}
