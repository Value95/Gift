﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerstart : MonoBehaviour
{
    public GameObject player;
    public PlayerMove move;
    public Animator anim;
    public Transform target;

    bool start = true;

    private void Start()
    {
        startevent();
    }

    // Update is called once per frame
    void Update()
    {
        if (start)
        {
            targetMove(target.gameObject, player, target.transform);
        }
    }

    void startevent()
    {
        anim.Play("Move");
        anim.SetFloat("Forward", 0.5f);
        anim.SetFloat("Sit", 0f);
        move.enabled = false;
    }

    void targetMove(GameObject mygameObjct, GameObject player, Transform target)
    {
        Vector3 vec = mygameObjct.transform.position;

        Vector3 vectorTarget = target.position;
        vectorTarget.y = player.transform.position.y;
        player.transform.position = Vector3.MoveTowards(player.transform.position, vectorTarget, 2 * Time.deltaTime);

        //수정필요
        //vec.x = player.transform.GetChild(0).transform.localPosition.x;
        player.transform.GetChild(0).transform.LookAt(vec);

        if (player.transform.position == vectorTarget)
        {
            move.enabled = true;
            Destroy(this.gameObject);
        }
    }
}
