﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutterEvent : MonoBehaviour
{
    ObjectEventName objEvent;

    // Start is called before the first frame update
    void Start()
    {
        objEvent = GetComponent<ObjectEventName>();
        objEvent.playerMove.enabled = false;
        objEvent.anim.Play("PickUp");
    }

    // Update is called once per frame
    void Update()
    {
        if (objEvent.anim.GetCurrentAnimatorStateInfo(0).IsName("PickUp"))
        {
            if (objEvent.anim.GetCurrentAnimatorStateInfo(0).normalizedTime > 0.45f)
                ThierdEnd();
        }
    }

    void ThierdEnd()
    {
        objEvent.playerMove.enabled = true;
        objEvent.player.GetComponent<PlayerFSM>().cutter = true;
        Destroy(this.gameObject);
    }
}

/// 플레이어 이동끄기
/// 줍기애니메이션
/// 플레이어 이동키기
/// 전선박스 이벤트실행
/// 자기자신삭제
