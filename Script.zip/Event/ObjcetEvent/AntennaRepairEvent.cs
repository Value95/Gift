﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class AntennaRepairEvent : MonoBehaviour
{
    ObjectEventName objEvent;

    public Transform consentTarget;

    bool consentMoveCheck = true;

    public PlayableDirector playableDirector;

    public Animator antennaAnim;
    public Animator Extraman;

    public List<EmissionFlash> flash = new List<EmissionFlash>();

    public List<GameObject> onEventObj = new List<GameObject>();
    public List<GameObject> offEventObj = new List<GameObject>();

    // Start is called before the first frame update
    void Start()
    {
        objEvent = GetComponent<ObjectEventName>();
        objEvent.playerMove.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (consentMoveCheck) // 해당위치까지이동
        {
            if (EventHelp.targetMove(this.gameObject, objEvent.player, consentTarget))
            {
                Play();
                antennaAnim.Play("Antenna_Push");
                consentMoveCheck = false;
            }
        }
    }

    void AntennaRepairEnd()
    {
        objEvent.playerMove.enabled = true;
        this.GetComponent<AntennaRepairEvent>().enabled = false;
        
        foreach(var obj in onEventObj)
        {
            obj.SetActive(true);
        }

        foreach (var obj in offEventObj)
        {
            obj.SetActive(false);
        }

        flash[0].lightFlashValue_MIN = 1;
        flash[1].lightFlashValue_MIN = 1;
        Extraman.Play("Extraman_Sit_Turn");
    }

    public void Play()
    {
        playableDirector.Play();
    }
}