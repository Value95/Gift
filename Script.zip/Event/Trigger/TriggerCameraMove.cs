﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerCameraMove : MonoBehaviour
{
    public bool dmove;
    public GameObject cameraObject;
    public GameObject[] checkPos;
    float[] disPos = new float[4];
    Vector3 nextPos;

    public float rotateSpeed;
    public float degree, cameraDistance;
    GameObject AI;
    private void Start()
    {
        AI = GameObject.Find("AIObject");
    }

    void OnTriggerStay(Collider col)
    {
        if (col.CompareTag("Player"))
        {
            
            disPos[0] = Vector3.Distance(col.transform.position, checkPos[0].transform.position);
            disPos[1] = Vector3.Distance(checkPos[0].transform.position, checkPos[1].transform.position);
            nextPos.x = checkPos[0].transform.position.x + (checkPos[1].transform.position.x - checkPos[0].transform.position.x) * (disPos[0]) / disPos[1];
            nextPos.y = checkPos[0].transform.position.y + (checkPos[1].transform.position.y - checkPos[0].transform.position.y) * (disPos[0]) / disPos[1];
            nextPos.z = checkPos[0].transform.position.z + (checkPos[1].transform.position.z - checkPos[0].transform.position.z) * (disPos[0]) / disPos[1];

            if (dmove)
            {
                cameraObject.GetComponent<CameraWalk>().newPos = checkPos[0].transform.position;
            }
            else
            {
                cameraObject.GetComponent<CameraWalk>().newPos = nextPos;
            }




            disPos[2] = Vector3.Distance(col.transform.position, checkPos[0].transform.position);
            disPos[3] = Vector3.Distance(col.transform.position, checkPos[1].transform.position);
            cameraObject.GetComponent<CameraWalk>().cameraDistance = cameraDistance;
            if (disPos[2] < disPos[3])
            {
                Turn(cameraObject, checkPos[2].transform.position);
            }
            else
            {
                Turn(cameraObject, checkPos[3].transform.position);
            }
        }
    }

    void Turn(GameObject obj, Vector3 target)
    {
        float dz = target.z - gameObject.transform.position.z;
        float dx = target.x - gameObject.transform.position.x;

        float rotateDegree = Mathf.Atan2(dx, dz) * Mathf.Rad2Deg;

        obj.transform.rotation = Quaternion.RotateTowards(obj.transform.rotation, Quaternion.Euler(degree, rotateDegree, 0), rotateSpeed * Time.deltaTime);
    }
}
