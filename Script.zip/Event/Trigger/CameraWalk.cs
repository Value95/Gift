﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraWalk : MonoBehaviour
{
    public float movementSpeed;
    public float cameraDistance;
    public Vector3 newPos;
    public bool Cinema;
    // Start is called before the first frame update
    void Start()
    {
        newPos = gameObject.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if(Cinema == false)
        CameraMove();
        
    }

    void CameraMove()
    {


        gameObject.transform.position = Vector3.Lerp(gameObject.transform.position, newPos, movementSpeed * Time.deltaTime);
        Camera.main.transform.localPosition = Vector3.Lerp(Camera.main.transform.localPosition, new Vector3(0, 0, -cameraDistance), movementSpeed * Time.deltaTime);
    }
}
