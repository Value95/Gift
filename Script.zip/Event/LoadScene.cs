﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScene : MonoBehaviour
{
    public int nextSceneNumber;
    // Start is called before the first frame update
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadSceneAsync(nextSceneNumber);
        }
    }

    public void NextScene()
    {
        SceneManager.LoadSceneAsync(nextSceneNumber);
    }


}
