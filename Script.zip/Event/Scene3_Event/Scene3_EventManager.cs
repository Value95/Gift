﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene3_EventManager : MonoBehaviour
{
    public int eventNumber;
    public GameObject player;
    public GameObject[] door;
    public GameObject puzzle;
    public GameObject textObject;
    public GameObject obstacle;
    bool textSet;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        switch (eventNumber)
        {
            case 0:
                if (puzzle.GetComponent<WireCutPuzzleManager>().clear)
                {
                    eventNumber++;
                    obstacle.SetActive(false);
                }
                break;
            case 1:
                if (player.GetComponent<PlayerFSM>().key == true && Vector3.Distance(player.transform.position, door[0].transform.position) <= 2 && Input.GetKeyDown(KeyCode.Z))
                {
                    eventNumber++;
                    door[0].GetComponent<Animator>().SetBool("Open", true);
                    player.GetComponent<PlayerFSM>().anim.Play("Card_Use");
                    MapSound_0.GetInstance().Door_OnSound_Start();
                }
                else if(player.GetComponent<PlayerFSM>().key == false && Vector3.Distance(player.transform.position, door[0].transform.position) <= 2 && Input.GetKeyDown(KeyCode.Z) && textSet == false)
                {
                    textSet = true;
                    textObject.GetComponent<UITextMessage>().textString = "카드 키가 필요해";
                    textObject.GetComponent<UITextMessage>().x_MAX = 9;
                    textObject.GetComponent<UITextMessage>().TextOn();
                }
                break;
        }
    }
}
