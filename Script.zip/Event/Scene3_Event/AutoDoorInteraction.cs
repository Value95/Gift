﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoDoorInteraction : MonoBehaviour
{
    

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GetComponent<Animator>().SetBool("Open", true);
            MapSound_0.GetInstance().Door_OnSound_Start();
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GetComponent<Animator>().SetBool("Open", false);
            MapSound_0.GetInstance().Door_OffSound_Start();
        }
    }
}
