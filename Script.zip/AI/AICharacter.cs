﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public enum AIState
{
    Idle,
    Patrol,
    Chase,
    Attack
}

public class AICharacter : MonoBehaviour
{
    public float patrolSpeed;
    public float chaseSpeed;

    

    public AIState AI_STATE;
    


    public Vector3 targetPos;
    public float chaseTime, patrolTime, idleTime, hideDistance;
    public bool playerHide, hack;

    GameObject navObject, navNextPosition;
    GameObject playerObject, rayCheckObject;
    Ray ray;
    RaycastHit hit;
    Camera cam;

    Animator animator;
    public float dis;
    public GameObject deathEvent;
    public int sceneNumber;
    public GameObject gunFireEffect;
    bool shot;
    // Start is called before the first frame update
    void Start()
    {
        animator = transform.GetChild(1).gameObject.GetComponent<Animator>();
        playerObject = GameObject.Find("Player");
        navObject = GameObject.Find("NavObject");
        navNextPosition = GameObject.Find("NavNextPosition");
        rayCheckObject = transform.GetChild(0).gameObject;
        cam = GetComponent<Camera>();
        ray = new Ray();
    }

    // Update is called once per frame
    void Update()
    {
        dis = Vector3.Distance(gameObject.transform.position, playerObject.transform.position);
        PlayerHideCheck();
        RayCheck();
        ChaseCheck();
        PatrolCheck();
        switch (AI_STATE)
        {
            case AIState.Idle:
                Idle();
                break;
            case AIState.Patrol:
                Patrol();
                break;
            case AIState.Chase:
                Chase();
                break;
            case AIState.Attack:
                Attack();
                break;
        }
        NavPos();
            navObject.GetComponent<NavMeshAgent>().destination = navNextPosition.transform.position;
        
    }
    

    void PlayerHideCheck()
    {
      if(  playerObject.GetComponent<PlayerFSM>().playerState== Player_State.Concealment)
        {
            if(Vector3.Distance(gameObject.transform.position, playerObject.transform.position) > hideDistance)
            {
                playerHide = true;
            }
        }
        else
        {
            playerHide = false;
        }
    }

    void Idle()
    {
        
    }

    void Patrol()
    {
       
        if (Vector3.Distance(gameObject.transform.position, navObject.transform.position)>1){
            Turn(gameObject, navObject.transform.position);
            transform.Translate(Vector3.forward * patrolSpeed * Time.deltaTime);
            animator.SetInteger("aniState", 1);
        }
        else
        {
            animator.SetInteger("aniState", 0);
        }
    }
    

    void Chase()
    {
        if (Vector3.Distance(gameObject.transform.position, navObject.transform.position) > 2)
        {
            Turn(gameObject, navObject.transform.position);
            transform.Translate(Vector3.forward * chaseSpeed * Time.deltaTime);
            animator.SetInteger("aniState", 2);
        }
        else
        {
            animator.SetInteger("aniState", 0);
        }
    }

    void Attack()
    {
        if (shot == false)
        {
            shot = true;
            
            deathEvent.GetComponent<DeathEventName>().onEvent();
            
            StartCoroutine("Reset");
        }
        Turn(gameObject, playerObject.transform.position);
        //playerObject.GetComponent<PlayerMove>().enabled = false;
        //playerObject.GetComponent<PlayerFSM>().playerState = Player_State.Death;
    }

    IEnumerator Reset()
    {
        yield return new WaitForSeconds(0.5f);
        gunFireEffect.transform.GetChild(0).gameObject.GetComponent<ParticleSystem>().Play();
        gunFireEffect.transform.GetChild(1).gameObject.GetComponent<ParticleSystem>().Play();
        animator.SetInteger("aniState", 0);
        yield return new WaitForSeconds(4f);
        shot = false;
        deathEvent.GetComponent<OtherObjectReset>().ResetOther(sceneNumber);
    }



    void RayCheck()
    {
        {
            Vector3 viewPos = cam.WorldToViewportPoint(playerObject.transform.position);
            if (viewPos.z > 0 && viewPos.x > 0 && viewPos.x < 1 && viewPos.y > 0 && viewPos.y < 1)
            {
                Vector3 rayPos = playerObject.transform.position;
                rayPos.y += 1;
                rayCheckObject.transform.LookAt(rayPos);


                ray.origin = rayCheckObject.transform.position;
                ray.direction = rayCheckObject.transform.forward;
                if (Physics.Raycast(ray.origin, ray.direction, out hit, 10))
                {

                    if (hit.collider.gameObject.CompareTag("Player"))
                    {
                        if(playerHide)
                        {

                            
                        }
                        else
                        {
                            
                            
                                navNextPosition.transform.position = playerObject.transform.position;
                                chaseTime = 6;
                                AI_STATE = AIState.Chase;
                            
                        }

                    }
                    else
                    {
                    }
                }
                else
                {
                }
                Debug.DrawRay(ray.origin, ray.direction * 10, Color.red);
            }
            else
            {
            }
        }
    }

    void ChaseCheck()
    {
        if (chaseTime > 0)
        {
            chaseTime -= Time.deltaTime;
            if (dis <= 3)
            {
                AI_STATE = AIState.Attack;
                Attack();
            }
        }
        else if(AI_STATE == AIState.Chase)
        {
            AI_STATE = AIState.Patrol;
            Vector3 newPos = new Vector3(Random.Range(-1000, 1000), Random.Range(-1000, 1000), Random.Range(-1000, 1000));
            navNextPosition.transform.position = newPos;
        }

    }

    void PatrolCheck()
    {
        if (patrolTime > 0)
        {
            if (Vector3.Distance(gameObject.transform.position, navNextPosition.transform.position) <=1)
            {
                if (idleTime > 0)
                {
                    idleTime -= Time.deltaTime;
                }
                else
                {
                    idleTime = 5;
                    patrolTime = 0;
                }
                
            }
                patrolTime -= Time.deltaTime;
            if (playerHide)
            {


            }
            else
            {
                if (dis < hideDistance)
                {
                    navNextPosition.transform.position = playerObject.transform.position;
                    chaseTime = 6;
                    AI_STATE = AIState.Chase;
                }
            }
        }
        else if (AI_STATE == AIState.Patrol)
        {
            //if (hack)
            //{
            //    patrolTime = 60;
            //    Vector3 newPos = playerObject.transform.position;
            //    navNextPosition.transform.position = newPos;
            //    hack = false;
            //}
            //else
            {
                patrolTime = 60;
                Vector3 newPos = new Vector3(Random.Range(-1000, 1000), Random.Range(-1000, 1000), Random.Range(-1000, 1000));
                navNextPosition.transform.position = newPos;
                
                hack = true;
            }
            
        }
    }

    void Turn(GameObject obj, Vector3 target)
    {
        float dz = target.z - gameObject.transform.position.z;
        float dx = target.x - gameObject.transform.position.x;

        float rotateDegree = Mathf.Atan2(dx, dz) * Mathf.Rad2Deg;

        obj.transform.rotation = Quaternion.RotateTowards(obj.transform.rotation, Quaternion.Euler(0, rotateDegree, 0), 600 * Time.deltaTime);
    }

    void NavPos()
    {
        if((gameObject.transform.position.x - navObject.transform.position.x) > 2)
        {
            Vector3 newPos = gameObject.transform.position;
            newPos.x -= 1.9f;
            navObject.transform.position = newPos;
        }
        if ((gameObject.transform.position.x - navObject.transform.position.x) <- 2)
        {
            Vector3 newPos = gameObject.transform.position;
            newPos.x += 1.9f;
            navObject.transform.position = newPos;
        }
        if ((gameObject.transform.position.z - navObject.transform.position.z) > 2)
        {
            Vector3 newPos = gameObject.transform.position;
            newPos.z -= 1.9f;
            navObject.transform.position = newPos;
        }
        if ((gameObject.transform.position.z - navObject.transform.position.z) <- 2)
        {
            Vector3 newPos = gameObject.transform.position;
            newPos.z +=1.9f;
            navObject.transform.position = newPos;
        }
    }
}
