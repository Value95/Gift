﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscMenuSet : MonoBehaviour
{
    public GameObject ESC;
    public bool Set;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && Set == false)
        {
            OpenTap();
        }
    }

    void OpenTap()
    {
        Time.timeScale = 0;
        Set = true;
        ESC.SetActive(true);
    }

    public void CloseTap()
    {
        Time.timeScale = 1;
        Set = false;
        ESC.SetActive(false);
    }
}
