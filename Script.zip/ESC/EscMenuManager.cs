﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class EscMenuManager : MonoBehaviour
{
    public int sceneNumber;
   

    public Canvas mycanvas; // raycast가 될 캔버스
    GraphicRaycaster gr;
    PointerEventData ped;



    public GameObject[] menu = new GameObject[3];
    public GameObject setObject;
    // Start is called before the first frame update
    void Start()
    {
        gr = mycanvas.GetComponent<GraphicRaycaster>();
        ped = new PointerEventData(null);

        
    }

    // Update is called once per frame
    void Update()
    {
        RayCheck();
    }

    void RayCheck()
    {



        if (Input.mousePosition != Vector3.zero)
        {
            ped.position = Input.mousePosition;

            List<RaycastResult> results = new List<RaycastResult>(); // 여기에 히트 된 개체 저장
            gr.Raycast(ped, results);

            //Debug.Log(results[0].gameObject.transform.parent.gameObject);





            if (results.Count != 0 && results[0].gameObject.transform.parent.gameObject.GetComponent<EscMenuObject>())
            {

                RenderChange(results[0].gameObject.transform.parent.gameObject, 1);
                if (Input.GetMouseButtonDown(0))
                {
                    switch (results[0].gameObject.transform.parent.gameObject.GetComponent<EscMenuObject>().objectNumber)
                    {
                        case 0:
                            setObject.GetComponent<EscMenuSet>().CloseTap();
                            break;
                        case 1:
                            Time.timeScale = 1;
                            SceneManager.LoadSceneAsync(sceneNumber);
                            break;
                        case 2:
                            Application.Quit();
                            
                            break;
                    }
                }
            }
            else
            {
                for (int i = 0; i < 3; i++)
                {
                    RenderChange(menu[i], 0);
                }
            }
        }
    }

    void RenderChange(GameObject obj, int num)
    {
        obj.transform.GetChild(0).gameObject.SetActive(false);
        obj.transform.GetChild(1).gameObject.SetActive(false);

        obj.transform.GetChild(num).gameObject.SetActive(true);
    }
}


