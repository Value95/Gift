﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightFlash : MonoBehaviour
{
    public int lightCount_MIN, lightCount_MAX;
    public float lightFlashTurm_MIN, lightFlashTurm_MAX;
    public float lightActiveTime_MIN, lightActiveTime_MAX;
    public GameObject lightObject;
    public GameObject lampObject;
    MeshRenderer lampMaterial;
    public bool firstFlash;
    public bool nolight;
    // Start is called before the first frame update
    void Start()
    {

        lampMaterial = lampObject.GetComponent<MeshRenderer>();
        StartCoroutine("LightActive");
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator LightActive()
    {
        bool lightSet = true;
        int flashCount = 0;
        int lightCount = Random.Range(lightCount_MIN, lightCount_MAX);
        while (true)
        {
            if (lightSet)
            {
                if (lightCount > Random.Range(lightCount_MIN, lightCount_MAX))
                {
                    lightSet = false;
                }
                else
                {
                    if(nolight == false)
                    lightObject.SetActive(true);
                    lampMaterial.material.SetFloat("_Brightness", 2.0f);
                    yield return new WaitForSeconds(Random.Range(lightFlashTurm_MIN, lightFlashTurm_MAX));
                    if (nolight == false)
                        lightObject.SetActive(false);
                    lampMaterial.material.SetFloat("_Brightness", 0.3f);
                    yield return new WaitForSeconds(Random.Range(lightFlashTurm_MIN, lightFlashTurm_MAX));
                    lightCount++;
                }
            }
            else
            {
                if (nolight == false)
                    lightObject.SetActive(true);
                lampMaterial.material.SetFloat("_Brightness", 2);
                yield return new WaitForSeconds(Random.Range(lightActiveTime_MIN, lightActiveTime_MAX));
                lightSet = true;
                lightCount = 0;
                flashCount++;
            }

            if (firstFlash && flashCount>1)
            {
                break;
            }
        }

    }
}